import LancerDes from "./components/lancerDes";
import "./App.css";

function App() {
  return (
    <div className="App">
      <LancerDes />
    </div>
  );
}

export default App;
