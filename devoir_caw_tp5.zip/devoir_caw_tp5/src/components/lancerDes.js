import { useState, useEffect } from "react";
import De from "./de";

const LancerDes = () => {
  const [de_1, setDe_1] = useState(0); // hooks
  const [de_2, setDe_2] = useState(0); // hooks

  // Bonus
  const [score, setScore] = useState(0);
  const [counter, setCounter] = useState(10);

  const randomIntFromInterval = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1) + min);
  };

  // before bonus question
  // const lancer = () => {
  //   setDe_1(randomIntFromInterval(1, 6));
  //   setDe_2(randomIntFromInterval(1, 6));
  // };

  const lancer = () => {
    setDe_1(randomIntFromInterval(1, 6));
    setDe_2(randomIntFromInterval(1, 6));
    setCounter(counter - 1);
  };

  const updateScore = (de1, de2) => {
    if (de1 === de2) {
      setScore(score + 1); // increment score by 1
    } else {
      setScore(score - 1); // decrement counter by 1
    }
  };

  const reset = () => {
    setDe_1(0);
    setDe_2(0);
    setScore(0);
    setCounter(10);
  };

  useEffect(() => {
    if (de_1 !== 0 && de_2 !== 0) {
      updateScore(de_1, de_2);
    }
  }, [de_1, de_2]);

  return (
    <div className="lancerDes">
      <div className="cadre">
        <h1>score: {score}</h1>
        <h1>counter: {counter}</h1>
        {de_1 !== 0 && de_2 !== 0 && (
          <h1 className="message">
            {de_1 === de_2 ? "You win!" : "Try again!"}
          </h1>
        )}
        <De de1={de_1} de2={de_2} />
      </div>
      <div className="des-button">
        <button
          disabled={counter <= 0}
          className="btn-lancer"
          onClick={counter > 0 ? lancer : ""}
        >
          Lancer les Dés
        </button>
        <button disabled={counter > 0} className="btn-reset" onClick={reset}>
          RESET
        </button>
      </div>
    </div>
  );
};

export default LancerDes;
