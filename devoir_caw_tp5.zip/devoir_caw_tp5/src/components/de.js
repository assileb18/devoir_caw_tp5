const De = (props) => {
  return (
    <div className="des-container">
      {(props.de1 || props.de2) !== 0 && (
        <>
          <img src={require(`../assets/${props.de1}.png`)} alt="de 1" />
          <img src={require(`../assets/${props.de2}.png`)} alt="de 2" />
        </>
      )}
      {(props.de1 || props.de2) === 0 && (
        <>
          <div></div>
          <div></div>
        </>
      )}
    </div>
  );
};

export default De;
